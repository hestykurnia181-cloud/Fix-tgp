# TGP Management — GitHub Android + iOS Build

Repository ini sekarang memiliki satu workflow utama: `.github/workflows/mobile-build.yml`.

Setiap push ke `main`/`master`, pull request, atau **Run workflow** akan mencoba membuat dua artifact terpisah:

1. `TGP-Management-Android-APK` → `TGP-Management-Android.apk`
2. `TGP-Management-iOS-Simulator` → `TGP-Management-iOS-Simulator.app.zip`

## Catatan iOS

Artifact iOS adalah **build untuk iOS Simulator dan unsigned**. Ini sengaja dipakai untuk memverifikasi bahwa proyek berhasil dikompilasi oleh Xcode di GitHub Actions.

Artifact ini **bukan IPA untuk iPhone/TestFlight/App Store**. Distribusi ke perangkat nyata memerlukan Apple Developer signing, certificate, provisioning profile, serta konfigurasi App Store Connect.

## Supabase

Untuk build yang terhubung ke Supabase, isi GitHub Repository Variables atau Secrets berikut:

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Jangan menaruh service-role key atau credential rahasia lain di source code.
