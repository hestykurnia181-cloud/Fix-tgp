<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/36625e55-1177-466f-9e1c-15bd4e6f72bb

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## iPhone tanpa Apple Developer (PWA)

Web build TGP Management disiapkan sebagai Progressive Web App (PWA). Setelah di-host melalui HTTPS, client iPhone dapat membuka URL di Safari dan memilih **Add to Home Screen**. Tidak diperlukan Apple Developer Program untuk jalur PWA.

PWA tidak menggantikan TestFlight/App Store untuk distribusi native. Pastikan `VITE_SUPABASE_URL` dan `VITE_SUPABASE_ANON_KEY` dikonfigurasi pada deployment web. Service worker hanya menangani shell dan aset aplikasi; trafik Supabase tidak dicache sebagai sumber data.
