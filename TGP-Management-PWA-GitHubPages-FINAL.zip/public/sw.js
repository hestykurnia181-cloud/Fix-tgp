const CACHE_VERSION = 'tgp-management-v1';
const APP_SHELL = ['./','./index.html','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE_VERSION).then(cache => cache.addAll(APP_SHELL))); self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_VERSION).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener('fetch', event => {
  const req = event.request; if (req.method !== 'GET') return;
  const url = new URL(req.url); if (url.origin !== self.location.origin) return;
  if (req.mode === 'navigate') {
    event.respondWith(fetch(req).then(res => { const copy=res.clone(); caches.open(CACHE_VERSION).then(c=>c.put('./index.html',copy)); return res; }).catch(()=>caches.match('./index.html'))); return;
  }
  if (!['script','style','image','font'].includes(req.destination)) return;
  event.respondWith(caches.match(req).then(cached => {
    const network = fetch(req).then(res => { if(res.ok){ const copy=res.clone(); caches.open(CACHE_VERSION).then(c=>c.put(req,copy)); } return res; }).catch(()=>cached);
    return cached || network;
  }));
});
