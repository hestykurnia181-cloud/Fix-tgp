# Revisi Laporan TGP

- Ekspor laporan sekarang menyediakan file Excel `.xlsx` yang dibuat langsung dari data periode dan bisnis/divisi aktif.
- Excel berisi sheet Ringkasan, Penjualan, Produk Terlaris, Pembayaran, serta Performa Jasa untuk bisnis SERVICE.
- Jurnal Mutasi Kas memisahkan tampilan Tanggal dan Waktu dan mengambil timestamp transaksi sebagai sumber utama.
- Waktu jurnal ditampilkan sampai detik; tanggal menampilkan tahun agar riwayat lebih jelas.
