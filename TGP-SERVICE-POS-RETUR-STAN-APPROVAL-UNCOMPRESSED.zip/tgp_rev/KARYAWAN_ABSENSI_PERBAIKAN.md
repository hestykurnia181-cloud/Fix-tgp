# Modul Karyawan & Absensi

Perubahan:
- Menu **Karyawan** tersedia untuk OWNER, ADMIN OWNER, dan ADMIN DIVISI.
- OWNER dapat melihat daftar karyawan dan laporan absensi pada bisnis yang dia miliki.
- ADMIN OWNER melihat dan mengelola karyawan pada bisnis yang ditugaskan.
- ADMIN DIVISI melihat dan mengelola karyawan pada divisinya.
- Tambah karyawan mencakup nama, username, password, role operasional, departemen, dan komisi jasa bila bisnis bertipe SERVICE.
- Laporan absensi menampilkan ringkasan per karyawan (hari terdata, masuk, pulang, status belum pulang) serta riwayat terbaru.
- Data absensi difilter berdasarkan bisnis yang benar-benar berwenang dilihat oleh akun aktif.
- Hirarki tetap dipertahankan: OWNER tidak membuat akun operasional langsung; pembuatan akun operasional tetap melalui ADMIN OWNER / ADMIN DIVISI.
