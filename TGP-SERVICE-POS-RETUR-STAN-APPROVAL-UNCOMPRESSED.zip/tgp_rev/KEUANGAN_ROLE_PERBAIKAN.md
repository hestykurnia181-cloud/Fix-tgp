# Perbaikan Akses Keuangan Role

Aturan akses finansial yang diterapkan:

- OWNER: dapat melihat dashboard keuangan, jurnal/buku kas, laporan finansial seluruh bisnis miliknya.
- ADMIN OWNER: dapat melihat dashboard keuangan, jurnal/buku kas, laporan finansial hanya pada bisnis yang ditugaskan.
- ADMIN DIVISI, MANAGER, KASIR, WAREHOUSE, STAFF: tidak dapat membuka FINANCE atau REPORTS dan tidak menerima data ledger finansial.
- Akses yang dipaksa melalui navigasi langsung juga ditolak oleh authorization di context.
- Hak `canViewFinance` untuk akun operasional baru tidak lagi memberikan akses ke laporan/ledger finansial.
- Dashboard operasional untuk role non-keuangan tidak menampilkan metrik finansial seperti omzet/komisi jasa.
