# Perbaikan Approval Retur STAN oleh Kasir

- Kasir hanya membuat permintaan retur dengan status PENDING/DRAFT.
- Tidak ada pengurangan stok STAN atau penambahan stok Gudang Barang Jadi saat draft dibuat.
- OWNER dan ADMIN OWNER dapat melihat permintaan sesuai scope bisnis dan menyetujui/menolak.
- Saat disetujui, stok STAN berkurang dan Gudang Barang Jadi bertambah secara bersamaan di state aplikasi, lalu disinkronkan.
- Saat ditolak, tidak ada perubahan stok.
- Riwayat retur menyimpan pengaju, approver, status, waktu pengajuan, dan waktu diproses.
- Badge Approval ikut menghitung pending retur STAN.
