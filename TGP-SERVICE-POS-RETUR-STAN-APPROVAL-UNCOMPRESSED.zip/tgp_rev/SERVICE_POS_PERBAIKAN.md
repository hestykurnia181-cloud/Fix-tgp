# TGP SERVICE POS — Perbaikan Petugas Jasa

Perbaikan ini menambahkan hubungan transaksi POS JASA dengan petugas yang benar-benar melayani jasa.

## Perubahan utama
- Checkout pada template `SERVICE` wajib memilih petugas yang melayani.
- Petugas ditampilkan dari staff operasional bisnis aktif.
- Saat transaksi selesai, sistem menyimpan snapshot `serviceStaffId`, `serviceStaffName`, persentase komisi, nominal bagian staff, dan bagian owner.
- Perubahan persentase komisi di profil staff tidak mengubah transaksi lama.
- Laporan bisnis JASA menampilkan performa petugas: jumlah jasa, omzet, bagian staff, dan bagian owner.
- Dashboard bisnis JASA menampilkan performa petugas hari ini.
- Struk mencantumkan petugas JASA dan bagian staff.
- SQL schema dan migration additive disertakan.

## Database
Untuk database Supabase yang sudah ada, jalankan:

`supabase-migration-service-pos.sql`

Migration bersifat additive menggunakan `ADD COLUMN IF NOT EXISTS`.
