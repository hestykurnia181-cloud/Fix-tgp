from pathlib import Path
p=Path('/mnt/data/tgp_rev/src/screens/ReportsScreen.tsx')
s=p.read_text()
insert = r'''
function xmlEscape(value: unknown): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

type ExcelCell = string | number | null | undefined;

function excelCellXml(value: ExcelCell): string {
  if (value === null || value === undefined) return '<c/>';
  if (typeof value === 'number' && Number.isFinite(value)) {
    return `<c t="n"><v>${value}</v></c>`;
  }
  return `<c t="inlineStr"><is><t xml:space="preserve">${xmlEscape(value)}</t></is></c>`;
}

function excelSheetXml(rows: ExcelCell[][]): string {
  const body = rows.map((row, rowIndex) => {
    const cells = row.map(excelCellXml).join('');
    return `<row r="${rowIndex + 1}">${cells}</row>`;
  }).join('');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`;
}

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i += 1) {
    crc ^= bytes[i];
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function writeU16(view: DataView, offset: number, value: number) {
  view.setUint16(offset, value, true);
}
function writeU32(view: DataView, offset: number, value: number) {
  view.setUint32(offset, value >>> 0, true);
}

function createStoredZip(entries: Array<{ name: string; content: string }>): Blob {
  const encoder = new TextEncoder();
  const parts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  entries.forEach((entry) => {
    const nameBytes = encoder.encode(entry.name);
    const data = encoder.encode(entry.content);
    const crc = crc32(data);
    const local = new Uint8Array(30 + nameBytes.length);
    const localView = new DataView(local.buffer);
    writeU32(localView, 0, 0x04034b50);
    writeU16(localView, 4, 20);
    writeU16(localView, 6, 0x800);
    writeU16(localView, 8, 0);
    writeU16(localView, 10, 0);
    writeU16(localView, 12, 0);
    writeU32(localView, 14, crc);
    writeU32(localView, 18, data.length);
    writeU32(localView, 22, data.length);
    writeU16(localView, 26, nameBytes.length);
    writeU16(localView, 28, 0);
    local.set(nameBytes, 30);
    parts.push(local, data);

    const central = new Uint8Array(46 + nameBytes.length);
    const centralView = new DataView(central.buffer);
    writeU32(centralView, 0, 0x02014b50);
    writeU16(centralView, 4, 20);
    writeU16(centralView, 6, 20);
    writeU16(centralView, 8, 0x800);
    writeU16(centralView, 10, 0);
    writeU16(centralView, 12, 0);
    writeU16(centralView, 14, 0);
    writeU32(centralView, 16, crc);
    writeU32(centralView, 20, data.length);
    writeU32(centralView, 24, data.length);
    writeU16(centralView, 28, nameBytes.length);
    writeU16(centralView, 30, 0);
    writeU16(centralView, 32, 0);
    writeU16(centralView, 34, 0);
    writeU16(centralView, 36, 0);
    writeU32(centralView, 38, 0);
    writeU32(centralView, 42, offset);
    central.set(nameBytes, 46);
    centralParts.push(central);

    offset += local.length + data.length;
  });

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const eocd = new Uint8Array(22);
  const eocdView = new DataView(eocd.buffer);
  writeU32(eocdView, 0, 0x06054b50);
  writeU16(eocdView, 4, 0);
  writeU16(eocdView, 6, 0);
  writeU16(eocdView, 8, entries.length);
  writeU16(eocdView, 10, entries.length);
  writeU32(eocdView, 12, centralSize);
  writeU32(eocdView, 16, offset);
  writeU16(eocdView, 20, 0);

  return new Blob([...parts, ...centralParts, eocd], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
}

function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}
'''
marker='const PIE_COLORS = ['
s=s.replace(marker, insert+'\n'+marker)
old="""  const handlePrint = () => window.print();\n\n  const handleExport = () => {"""
new="""  const handlePrint = () => window.print();\n\n  const handleExportExcel = () => {\n    const businessName = activeBusiness?.name || 'Bisnis';\n    const createdAt = new Date();\n    const salesRows: ExcelCell[][] = [\n      ['Laporan Penjualan', periodLabel],\n      ['Bisnis/Divisi', businessName],\n      ['Dibuat', createdAt.toLocaleString('id-ID')],\n      [],\n      ['No', 'Tanggal', 'Waktu', 'Struk', 'Kasir', ...(isServiceBusiness ? ['Petugas Jasa'] : []), 'Rincian', 'Metode Pembayaran', 'Total'],\n      ...filteredSales.map((sale, index) => {\n        const stamp = new Date(sale.timestamp);\n        return [\n          index + 1,\n          stamp.toLocaleDateString('id-ID'),\n          stamp.toLocaleTimeString('id-ID'),\n          sale.receiptNumber,\n          sale.cashierName,\n          ...(isServiceBusiness ? [sale.serviceStaffName || (sale.items || []).find((i) => i.serviceStaffName)?.serviceStaffName || '-'] : []),\n          sale.itemsSummary,\n          sale.paymentMethod,\n          Number(sale.totalAmount || 0),\n        ];\n      }),\n    ];\n\n    const summaryRows: ExcelCell[][] = [\n      ['Ringkasan', 'Nilai'],\n      ['Periode', periodLabel],\n      ['Total Penjualan', totalSalesRevenue],\n      ['Jumlah Struk', filteredSales.length],\n      [],\n      ['Produk/Jasa Terlaris', 'Jumlah Terjual', 'Omzet'],\n      ...bestSellers.map((row) => [row.name, row.quantity, row.revenue]),\n    ];\n\n    const paymentRows: ExcelCell[][] = [\n      ['Metode Pembayaran', 'Total'],\n      ...paymentMix.map(([name, value]) => [name, value]),\n    ];\n\n    const serviceRows: ExcelCell[][] = [\n      ['Petugas', 'Jumlah Jasa', 'Omzet', 'Bagian Staff', 'Bagian Owner'],\n      ...servicePerformance.map((row) => [row.name, row.jobs, row.revenue, row.commission, row.ownerShare]),\n    ];\n\n    const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Ringkasan" sheetId="1" r:id="rId1"/><sheet name="Penjualan" sheetId="2" r:id="rId2"/><sheet name="Produk Terlaris" sheetId="3" r:id="rId3"/><sheet name="Pembayaran" sheetId="4" r:id="rId4"/>${isServiceBusiness ? '<sheet name="Performa Jasa" sheetId="5" r:id="rId5"/>' : ''}</sheets></workbook>`;\n    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/>${isServiceBusiness ? '<Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet5.xml"/>' : ''}</Relationships>`;\n    const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`;\n    const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Laporan Penjualan ${xmlEscape(businessName)}</dc:title><dc:creator>TGP</dc:creator><dc:description>Laporan ${xmlEscape(periodLabel)}</dc:description></cp:coreProperties>`;\n    const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>${isServiceBusiness ? '<Override PartName="/xl/worksheets/sheet5.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' : ''}</Types>`;\n\n    const entries = [\n      { name: '[Content_Types].xml', content: contentTypes },\n      { name: '_rels/.rels', content: rootRels },\n      { name: 'docProps/core.xml', content: core },\n      { name: 'xl/workbook.xml', content: workbookXml },\n      { name: 'xl/_rels/workbook.xml.rels', content: rels },\n      { name: 'xl/worksheets/sheet1.xml', content: excelSheetXml(summaryRows) },\n      { name: 'xl/worksheets/sheet2.xml', content: excelSheetXml(salesRows) },\n      { name: 'xl/worksheets/sheet3.xml', content: excelSheetXml([['Produk/Jasa', 'Jumlah Terjual', 'Omzet'], ...bestSellers.map((row) => [row.name, row.quantity, row.revenue])]) },\n      { name: 'xl/worksheets/sheet4.xml', content: excelSheetXml(paymentRows) },\n    ];\n    if (isServiceBusiness) entries.push({ name: 'xl/worksheets/sheet5.xml', content: excelSheetXml(serviceRows) });\n\n    downloadBlob(createStoredZip(entries), `laporan-${toSafeFileName(businessName)}-${dateFilter.toLowerCase()}.xlsx`);\n  };\n\n  const handleExport = () => {"""
if old not in s: raise SystemExit('marker old not found')
s=s.replace(old,new)
old_button='''<button onClick={handleExport} className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"><Download className="w-4 h-4" /> Ekspor Laporan</button>'''
new_button='''<button onClick={handleExportExcel} className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"><FileSpreadsheet className="w-4 h-4" /> Excel</button>\n          <button onClick={handleExport} className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"><Download className="w-4 h-4" /> HTML</button>'''
if old_button not in s: raise SystemExit('button marker not found')
s=s.replace(old_button,new_button)
p.write_text(s)

p=Path('/mnt/data/tgp_rev/src/screens/FinanceScreen.tsx')
s=p.read_text()
s=s.replace('''                <th className="py-2.5 px-3">Waktu</th>''','''                <th className="py-2.5 px-3">Tanggal</th>\n                <th className="py-2.5 px-3">Waktu</th>''')
old='''                      <td className="py-3 px-3">\n                        <div className="font-semibold text-slate-800">\n                          {new Date(l.date).toLocaleDateString('id-ID', {\n                            day: '2-digit',\n                            month: 'short',\n                          })}\n                        </div>\n                        <span className="text-[10px] text-slate-400">\n                          {new Date(l.date).toLocaleTimeString('id-ID', {\n                            hour: '2-digit',\n                            minute: '2-digit',\n                          })}\n                        </span>\n                      </td>'''
new='''                      <td className="py-3 px-3">\n                        <div className="font-semibold text-slate-800">\n                          {new Date(l.timestamp || l.date || 0).toLocaleDateString('id-ID', {\n                            day: '2-digit',\n                            month: 'short',\n                            year: 'numeric',\n                          })}\n                        </div>\n                      </td>\n                      <td className="py-3 px-3">\n                        <span className="text-[11px] text-slate-600 font-semibold">\n                          {new Date(l.timestamp || l.date || 0).toLocaleTimeString('id-ID', {\n                            hour: '2-digit',\n                            minute: '2-digit',\n                            second: '2-digit',\n                          })}\n                        </span>\n                      </td>'''
if old not in s: raise SystemExit('finance cell marker not found')
s=s.replace(old,new)
s=s.replace('''<td colSpan={4}''','''<td colSpan={5}''')
p.write_text(s)
