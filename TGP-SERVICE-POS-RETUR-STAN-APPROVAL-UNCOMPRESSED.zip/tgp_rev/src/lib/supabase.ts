/// <reference types="vite/client" />
import { createClient, SupabaseClient } from '@supabase/supabase-js';

export function getActiveSupabaseConfig(): { url: string; anonKey: string; source: 'ENV' | 'LOCAL' | 'NONE' } {
  const envUrl = ((import.meta as any).env?.VITE_SUPABASE_URL || '') as string;
  const envKey = ((import.meta as any).env?.VITE_SUPABASE_ANON_KEY || '') as string;

  if (typeof window !== 'undefined') {
    const localUrl = localStorage.getItem('tgp_supabase_url');
    const localKey = localStorage.getItem('tgp_supabase_anon_key');
    if (localUrl && localKey && localUrl.trim().length > 0 && localKey.trim().length > 0) {
      return { url: localUrl.trim(), anonKey: localKey.trim(), source: 'LOCAL' };
    }
  }

  if (envUrl && envKey && envUrl.trim().length > 0 && envKey.trim().length > 0) {
    return { url: envUrl.trim(), anonKey: envKey.trim(), source: 'ENV' };
  }

  return { url: '', anonKey: '', source: 'NONE' };
}

const initialConfig = getActiveSupabaseConfig();
export let supabaseUrl: string = initialConfig.url;
export let supabaseAnonKey: string = initialConfig.anonKey;

export function checkIsSupabaseConfigured(url = supabaseUrl, key = supabaseAnonKey): boolean {
  return Boolean(
    url &&
    key &&
    (url.startsWith('https://') || url.startsWith('http://')) &&
    key.length >= 20
  );
}

export let isSupabaseConfigured: boolean = checkIsSupabaseConfigured();

let cachedClient: SupabaseClient | null = null;

export function setCustomSupabaseConfig(url: string, key: string): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem('tgp_supabase_url', url.trim());
    localStorage.setItem('tgp_supabase_anon_key', key.trim());
  }
  supabaseUrl = url.trim();
  supabaseAnonKey = key.trim();
  isSupabaseConfigured = checkIsSupabaseConfigured(supabaseUrl, supabaseAnonKey);
  cachedClient = null;
}

export function resetCustomSupabaseConfig(): void {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('tgp_supabase_url');
    localStorage.removeItem('tgp_supabase_anon_key');
  }
  const envConfig = {
    url: (((import.meta as any).env?.VITE_SUPABASE_URL || '') as string).trim(),
    anonKey: (((import.meta as any).env?.VITE_SUPABASE_ANON_KEY || '') as string).trim(),
  };
  supabaseUrl = envConfig.url;
  supabaseAnonKey = envConfig.anonKey;
  isSupabaseConfigured = checkIsSupabaseConfigured(supabaseUrl, supabaseAnonKey);
  cachedClient = null;
}

/**
 * Returns the initialized Supabase client if configured, or null.
 * Ensures lazy initialization and avoids crashing the app if env vars are missing.
 */
export function getSupabaseClient(): SupabaseClient | null {
  const currentConfig = getActiveSupabaseConfig();
  if (!checkIsSupabaseConfigured(currentConfig.url, currentConfig.anonKey)) {
    return null;
  }

  if (!cachedClient || supabaseUrl !== currentConfig.url || supabaseAnonKey !== currentConfig.anonKey) {
    supabaseUrl = currentConfig.url;
    supabaseAnonKey = currentConfig.anonKey;
    isSupabaseConfigured = true;
    try {
      cachedClient = createClient(supabaseUrl, supabaseAnonKey, {
        auth: {
          persistSession: false,
          autoRefreshToken: false,
        },
        realtime: {
          params: {
            eventsPerSecond: 15,
          },
        },
      });
    } catch (err) {
      console.warn('[Supabase] Initialization error:', err);
      return null;
    }
  }

  return cachedClient;
}
