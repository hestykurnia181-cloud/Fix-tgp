import React, { useMemo, useState } from 'react';
import { ArrowDownToLine, CheckCircle2, ClipboardList, Package, Store } from 'lucide-react';
import { StatCard } from '../components/StatCard';
import { useTgp } from '../context/TgpContext';

function formatRupiah(amount: number): string {
  return 'Rp ' + Math.round(amount).toLocaleString('id-ID');
}

export const CashierReturnStockScreen: React.FC = () => {
  const { activeBusiness, activeOutlets, activeOutletStocks, returnStockFromStan, activeStanTransfers, currentSession } = useTgp();
  const assignedOutlet = activeOutlets[0] || null;
  const outletStocks = useMemo(
    () => activeOutletStocks.filter((s) => s.outletId === assignedOutlet?.outletId && s.stockQuantity > 0),
    [activeOutletStocks, assignedOutlet?.outletId]
  );
  const [itemId, setItemId] = useState(outletStocks[0]?.itemId || '');
  const [quantity, setQuantity] = useState('1');
  const [notes, setNotes] = useState('');

  const selectedStock = outletStocks.find((s) => s.itemId === itemId) || null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignedOutlet || !selectedStock) return;
    const qty = Math.floor(Number(quantity));
    if (!Number.isFinite(qty) || qty <= 0 || qty > selectedStock.stockQuantity) return;
    const ok = returnStockFromStan(
      assignedOutlet.outletId,
      selectedStock.itemId,
      qty,
      notes.trim() || `Pengembalian stok oleh Kasir dari ${assignedOutlet.name} ke Gudang Barang Jadi`
    );
    if (ok) {
      setQuantity('1');
      setNotes('');
    }
  };

  if (!currentSession?.user.outletId || !assignedOutlet) {
    return (
      <div className="max-w-xl mx-auto py-10">
        <div className="bg-white rounded-3xl p-7 border border-amber-200 text-center shadow-xs">
          <Store className="w-10 h-10 mx-auto text-amber-500" />
          <h2 className="mt-3 text-lg font-extrabold text-slate-900">STAN Kasir belum tersedia</h2>
          <p className="mt-1 text-xs text-slate-500">Akun ini belum memiliki STAN/Outlet aktif. Hubungi Admin untuk penugasan.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 pb-20 max-w-5xl mx-auto">
      <div className="bg-white rounded-3xl p-5 border border-amber-200 shadow-xs flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-amber-700 text-xs font-extrabold uppercase tracking-wider">
            <ArrowDownToLine className="w-4 h-4" />
            Pengembalian Stok
          </div>
          <h2 className="mt-1 text-xl font-extrabold text-slate-900">Kembalikan Stok ke Gudang Barang Jadi</h2>
          <p className="mt-1 text-xs text-slate-500 font-medium">
            Kasir hanya dapat mengembalikan stok dari STAN yang ditugaskan.
          </p>
        </div>
        <div className="shrink-0 px-3 py-2 rounded-xl bg-amber-50 border border-amber-200 text-right">
          <div className="text-[10px] text-amber-600 font-bold uppercase">STAN</div>
          <div className="text-sm font-extrabold text-amber-950">{assignedOutlet.name}</div>
          <div className="text-[10px] text-amber-700 font-mono">{assignedOutlet.code}</div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <StatCard title="Item Tersedia untuk Retur" value={`${outletStocks.length} Item`} icon={<Package className="w-4 h-4" />} color="blue" subtitle="Stok aktif di STAN" />
        <StatCard title="Total Stok STAN" value={`${outletStocks.reduce((a, s) => a + s.stockQuantity, 0)} Pcs`} icon={<ClipboardList className="w-4 h-4" />} color="amber" subtitle="Bisa dikembalikan" />
        <StatCard title="Status STAN" value="AKTIF" icon={<CheckCircle2 className="w-4 h-4" />} color="emerald" subtitle="STAN terikat ke akun Kasir" />
      </div>

      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs">
        {outletStocks.length === 0 ? (
          <div className="py-12 text-center">
            <Package className="w-9 h-9 mx-auto text-slate-300" />
            <h3 className="mt-3 text-sm font-extrabold text-slate-800">Tidak ada stok yang dapat dikembalikan</h3>
            <p className="mt-1 text-xs text-slate-400">Stok STAN {assignedOutlet.name} saat ini kosong.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-extrabold text-slate-700 mb-1.5">Produk / Menu</label>
              <select
                value={itemId}
                onChange={(e) => { setItemId(e.target.value); setQuantity('1'); }}
                className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500"
              >
                {outletStocks.map((stock) => (
                  <option key={stock.stockId} value={stock.itemId}>
                    {stock.itemName} — tersedia {stock.stockQuantity} {stock.unit}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-extrabold text-slate-700 mb-1.5">Jumlah Pengembalian</label>
                <input
                  type="number"
                  min="1"
                  max={selectedStock?.stockQuantity || 1}
                  step="1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm font-bold focus:outline-none focus:ring-2 focus:ring-amber-500"
                  required
                />
                <p className="mt-1 text-[10px] text-slate-400">
                  Maksimal {selectedStock?.stockQuantity || 0} {selectedStock?.unit || 'pcs'}
                </p>
              </div>
              <div>
                <label className="block text-xs font-extrabold text-slate-700 mb-1.5">Catatan Retur</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Contoh: Stok tidak habis / penutupan stan"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />
              </div>
            </div>

            <div className="rounded-2xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-900">
              <strong>Tujuan:</strong> Gudang Barang Jadi {activeBusiness ? `(${activeBusiness.name})` : ''}. <strong>Stok TIDAK berubah saat diajukan.</strong> Setelah Owner/Admin Owner menyetujui, stok STAN akan berkurang dan stok Gudang Barang Jadi bertambah.
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!selectedStock || Number(quantity) <= 0 || Number(quantity) > (selectedStock?.stockQuantity || 0)}
                className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-extrabold shadow-xs flex items-center gap-2"
              >
                <ArrowDownToLine className="w-4 h-4" />
                Ajukan Pengembalian
              </button>
            </div>
          </form>
        )}
      </div>

      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between gap-3 mb-3">
          <div>
            <h3 className="text-sm font-extrabold text-slate-900">Riwayat Pengembalian STAN</h3>
            <p className="text-[11px] text-slate-500">Permintaan Anda tidak mengubah stok sampai disetujui.</p>
          </div>
          <span className="px-2.5 py-1 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-extrabold">
            {activeStanTransfers.filter((st) => st.outletId === assignedOutlet.outletId && st.direction === 'STAN_TO_PRODUCTION').slice(0, 20).length} terbaru
          </span>
        </div>
        <div className="space-y-2">
          {activeStanTransfers.filter((st) => st.outletId === assignedOutlet.outletId && st.direction === 'STAN_TO_PRODUCTION').slice(0, 8).map((st) => (
            <div key={st.transferId} className="p-3 rounded-2xl border border-slate-100 bg-slate-50/70 flex items-center justify-between gap-3">
              <div className="min-w-0">
                <div className="text-xs font-extrabold text-slate-900 truncate">{st.itemName} × {st.quantity}</div>
                <div className="text-[10px] text-slate-500">{st.transferReference} · {new Date(st.timestamp).toLocaleString('id-ID')}</div>
              </div>
              <span className={`shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-extrabold ${
                st.status === 'PENDING' ? 'bg-amber-100 text-amber-800' : st.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                {st.status === 'PENDING' ? 'DRAFT / MENUNGGU APPROVAL' : st.status === 'APPROVED' ? 'DISETUJUI' : 'DITOLAK'}
              </span>
            </div>
          ))}
          {activeStanTransfers.filter((st) => st.outletId === assignedOutlet.outletId && st.direction === 'STAN_TO_PRODUCTION').length === 0 && (
            <div className="py-7 text-center text-xs text-slate-400">Belum ada pengembalian stok.</div>
          )}
        </div>
      </div>
    </div>
  );
};
