import React, { useMemo, useState } from 'react';
import { CalendarCheck, Plus, Users, UserPlus, Clock3, ShieldCheck } from 'lucide-react';
import { StatCard } from '../components/StatCard';
import { RoleBadge } from '../components/CommonBadges';
import { useTgp } from '../context/TgpContext';
import { StaffDepartment, UserRole } from '../types';

const operationalRoles = [
  UserRole.ADMIN_DIVISI,
  UserRole.MANAGER,
  UserRole.KASIR,
  UserRole.WAREHOUSE,
  UserRole.STAFF,
];

const departments: Array<{ value: StaffDepartment; label: string }> = [
  { value: 'GUDANG_BAHAN_BAKU', label: 'Gudang Bahan Baku' },
  { value: 'GUDANG_STOK', label: 'Gudang Stok / Barang Jadi' },
  { value: 'PRODUKSI', label: 'Produksi' },
  { value: 'KASIR_STAN', label: 'Kasir STAN' },
  { value: 'OPERASIONAL_UMUM', label: 'Operasional Umum' },
];

const fmtTime = (ts?: number) => (ts ? new Date(ts).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) : '-');
const fmtDate = (ts: number) => new Date(ts).toLocaleDateString('id-ID', { day: '2-digit', month: '2-digit', year: 'numeric' });

export const EmployeeManagementScreen: React.FC = () => {
  const {
    currentSession,
    authorizedBusinesses,
    allUsers,
    allAttendances,
    activeBusiness,
    createStaff,
    userMessage,
  } = useTgp();

  const role = currentSession?.user.role as UserRole | undefined;
  const canManage = role === UserRole.ADMIN_OWNER || role === UserRole.ADMIN_DIVISI;
  const canView = role === UserRole.OWNER || canManage;
  const [selectedBusinessId, setSelectedBusinessId] = useState(activeBusiness?.businessId || authorizedBusinesses[0]?.businessId || '');
  const [selectedEmployeeId, setSelectedEmployeeId] = useState('');
  const [tab, setTab] = useState<'employees' | 'attendance'>('employees');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [targetRole, setTargetRole] = useState<UserRole>(UserRole.STAFF);
  const [department, setDepartment] = useState<StaffDepartment>('OPERASIONAL_UMUM');
  const [commission, setCommission] = useState('0');

  const selectedBusiness = authorizedBusinesses.find((b) => b.businessId === selectedBusinessId) || null;
  const employees = useMemo(() => allUsers.filter((u) => {
    const r = u.role as UserRole;
    if ([UserRole.MASTER, UserRole.OWNER].includes(r)) return false;
    return u.businessId === selectedBusinessId || (u.assignedBusinessIds || []).includes(selectedBusinessId);
  }), [allUsers, selectedBusinessId]);

  const businessAttendance = useMemo(() => {
    const bizIds = new Set(authorizedBusinesses.map((b) => b.businessId));
    return allAttendances.filter((a) => bizIds.has(a.businessId) && (!selectedBusinessId || a.businessId === selectedBusinessId))
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [allAttendances, authorizedBusinesses, selectedBusinessId]);

  const attendanceSummary = useMemo(() => {
    const byUser = new Map<string, { name: string; dates: Set<string>; masuk: number; pulang: number; incomplete: number }>();
    for (const att of businessAttendance) {
      const date = new Date(att.timestamp).toLocaleDateString('id-ID');
      const row = byUser.get(att.userId) || { name: att.userName, dates: new Set<string>(), masuk: 0, pulang: 0, incomplete: 0 };
      row.dates.add(date);
      if (att.type === 'MASUK') row.masuk += 1;
      else row.pulang += 1;
      byUser.set(att.userId, row);
    }
    return Array.from(byUser.entries()).map(([userId, row]) => ({ userId, ...row, days: row.dates.size, incomplete: Math.max(0, row.masuk - row.pulang) }));
  }, [businessAttendance]);

  const handleCreate = () => {
    const ok = createStaff(
      selectedBusinessId,
      username,
      password,
      fullName,
      targetRole,
      undefined,
      department,
      undefined,
      Number(commission || 0),
    );
    if (ok) {
      setUsername(''); setPassword(''); setFullName(''); setCommission('0');
    }
  };

  if (!canView) {
    return <div className="bg-white rounded-3xl p-8 text-center text-sm text-slate-500">Akses Kelola Karyawan hanya tersedia untuk OWNER, ADMIN OWNER, dan ADMIN DIVISI.</div>;
  }

  return (
    <div className="space-y-5 pb-20">
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white"><Users className="w-6 h-6" /></div>
          <div>
            <div className="text-xs font-bold text-indigo-600 uppercase tracking-wider">SDM & Presensi</div>
            <h2 className="text-lg font-extrabold text-slate-900">Kelola Karyawan & Laporan Absensi</h2>
            <p className="text-xs text-slate-500">Rekap karyawan dan presensi per divisi bisnis.</p>
          </div>
        </div>
        <RoleBadge role={role || UserRole.STAFF} />
      </div>

      <div className="bg-white rounded-3xl p-4 border border-slate-200/80 shadow-xs">
        <label className="block text-xs font-bold text-slate-700 mb-1.5">Divisi / Bisnis</label>
        <select value={selectedBusinessId} onChange={(e) => setSelectedBusinessId(e.target.value)} className="w-full px-3 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold">
          {authorizedBusinesses.map((b) => <option key={b.businessId} value={b.businessId}>{b.name}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <StatCard title="Karyawan" value={`${employees.length}`} icon={<Users className="w-4 h-4" />} color="blue" subtitle={selectedBusiness?.name || 'Bisnis'} />
        <StatCard title="Hari Terdata" value={`${new Set(businessAttendance.map((a) => new Date(a.timestamp).toDateString())).size}`} icon={<CalendarCheck className="w-4 h-4" />} color="emerald" subtitle="Periode data tersimpan" />
      </div>

      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="flex border-b border-slate-100">
          <button onClick={() => setTab('employees')} className={`flex-1 py-3 text-xs font-extrabold ${tab === 'employees' ? 'text-indigo-700 bg-indigo-50' : 'text-slate-500'}`}>Kelola Karyawan</button>
          <button onClick={() => setTab('attendance')} className={`flex-1 py-3 text-xs font-extrabold ${tab === 'attendance' ? 'text-indigo-700 bg-indigo-50' : 'text-slate-500'}`}>Laporan Absensi</button>
        </div>

        {tab === 'employees' ? (
          <div className="p-5 space-y-5">
            {canManage ? (
              <div className="rounded-2xl bg-slate-50 border border-slate-200 p-4 space-y-3">
                <div className="flex items-center gap-2 text-sm font-extrabold text-slate-900"><UserPlus className="w-4 h-4" /> Tambah Karyawan</div>
                <input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Nama lengkap" className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs" />
                <div className="grid grid-cols-2 gap-3">
                  <input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username" className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs" />
                  <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password min. 6" type="password" className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <select value={targetRole} onChange={(e) => setTargetRole(e.target.value as UserRole)} className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold">
                    {operationalRoles.filter((r) => r !== UserRole.ADMIN_DIVISI || role !== UserRole.ADMIN_DIVISI).map((r) => <option key={r} value={r}>{r}</option>)}
                  </select>
                  <select value={department} onChange={(e) => setDepartment(e.target.value as StaffDepartment)} className="px-3 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold">
                    {departments.map((d) => <option key={d.value} value={d.value}>{d.label}</option>)}
                  </select>
                </div>
                {selectedBusiness?.templateType === 'SERVICE' && (
                  <input value={commission} onChange={(e) => setCommission(e.target.value)} type="number" min="0" max="100" placeholder="Komisi jasa (%)" className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs" />
                )}
                <button onClick={handleCreate} className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold flex items-center justify-center gap-2"><Plus className="w-4 h-4" /> Simpan Karyawan</button>
                {userMessage && <p className="text-[11px] text-emerald-700 font-semibold">{userMessage}</p>}
              </div>
            ) : (
              <div className="rounded-2xl bg-blue-50 border border-blue-100 p-4 text-xs text-blue-800 font-semibold">OWNER memiliki akses melihat daftar karyawan dan laporan absensi. Pembuatan akun operasional tetap mengikuti hierarki TGP melalui ADMIN OWNER / ADMIN DIVISI.</div>
            )}

            <div className="space-y-2">
              <div className="text-xs font-extrabold uppercase tracking-wider text-slate-500">Daftar Karyawan ({employees.length})</div>
              {employees.length === 0 ? <p className="py-6 text-center text-xs text-slate-400">Belum ada karyawan di bisnis ini.</p> : employees.map((u) => (
                <button key={u.userId} onClick={() => setSelectedEmployeeId(u.userId)} className={`w-full text-left p-3.5 rounded-2xl border ${selectedEmployeeId === u.userId ? 'border-indigo-400 bg-indigo-50' : 'border-slate-100 bg-slate-50'}`}>
                  <div className="flex items-center justify-between gap-3">
                    <div><p className="font-bold text-xs text-slate-900">{u.fullName}</p><p className="text-[10px] text-slate-500">{u.username} • {u.department || 'OPERASIONAL_UMUM'}</p></div>
                    <span className="text-[10px] font-extrabold px-2 py-1 rounded-lg bg-white border border-slate-200">{u.role}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="p-5 space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <StatCard title="Log Masuk" value={`${businessAttendance.filter((a) => a.type === 'MASUK').length}`} icon={<Clock3 className="w-4 h-4" />} color="emerald" subtitle="Presensi masuk" />
              <StatCard title="Log Pulang" value={`${businessAttendance.filter((a) => a.type === 'PULANG').length}`} icon={<ShieldCheck className="w-4 h-4" />} color="orange" subtitle="Presensi pulang" />
            </div>
            <div className="space-y-2">
              {attendanceSummary.length === 0 ? <p className="py-8 text-center text-xs text-slate-400">Belum ada data absensi di divisi ini.</p> : attendanceSummary.map((row) => (
                <div key={row.userId} className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                  <div className="flex items-center justify-between gap-3">
                    <div><p className="font-extrabold text-xs text-slate-900">{row.name}</p><p className="text-[10px] text-slate-500">{row.days} hari • {row.masuk} masuk • {row.pulang} pulang</p></div>
                    <span className={`text-[10px] font-extrabold px-2 py-1 rounded-lg ${row.incomplete ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>{row.incomplete ? `${row.incomplete} belum pulang` : 'Lengkap'}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <div className="text-xs font-extrabold uppercase tracking-wider text-slate-500">Riwayat Terbaru</div>
              {businessAttendance.slice(0, 30).map((a) => <div key={a.attendanceId} className="flex items-center justify-between p-3 rounded-xl bg-white border border-slate-100 text-xs"><div><p className="font-bold text-slate-900">{a.userName}</p><p className="text-[10px] text-slate-400">{fmtDate(a.timestamp)} • {a.note || 'Tanpa catatan'}</p></div><div className="text-right"><span className={`font-extrabold ${a.type === 'MASUK' ? 'text-emerald-600' : 'text-orange-600'}`}>{a.type}</span><span className="block text-[10px] text-slate-400">{fmtTime(a.timestamp)}</span></div></div>)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
