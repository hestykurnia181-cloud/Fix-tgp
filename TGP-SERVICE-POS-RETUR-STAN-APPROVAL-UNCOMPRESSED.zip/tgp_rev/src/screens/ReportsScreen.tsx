import React, { useMemo, useState } from 'react';
import {
  Calendar,
  DollarSign,
  Download,
  FileSpreadsheet,
  Package,
  Printer,
  Receipt,
  TrendingUp,
  Trophy,
} from 'lucide-react';
import { StatCard } from '../components/StatCard';
import { BusinessTemplate, UserRole } from '../types';
import { useTgp } from '../context/TgpContext';

function formatRupiah(amount: number): string {
  return 'Rp ' + Math.round(Number(amount) || 0).toLocaleString('id-ID');
}

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  const day = x.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  x.setDate(x.getDate() + diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

function toSafeFileName(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'bisnis';
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c] || c));
}


function xmlEscape(value: unknown): string {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

type ExcelCell = string | number | null | undefined;

function excelCellXml(value: ExcelCell): string {
  if (value === null || value === undefined) return '<c/>';
  if (typeof value === 'number' && Number.isFinite(value)) {
    return `<c t="n"><v>${value}</v></c>`;
  }
  return `<c t="inlineStr"><is><t xml:space="preserve">${xmlEscape(value)}</t></is></c>`;
}

function excelSheetXml(rows: ExcelCell[][]): string {
  const body = rows.map((row, rowIndex) => {
    const cells = row.map(excelCellXml).join('');
    return `<row r="${rowIndex + 1}">${cells}</row>`;
  }).join('');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${body}</sheetData></worksheet>`;
}

function crc32(bytes: Uint8Array): number {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i += 1) {
    crc ^= bytes[i];
    for (let bit = 0; bit < 8; bit += 1) {
      crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
    }
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function writeU16(view: DataView, offset: number, value: number) {
  view.setUint16(offset, value, true);
}
function writeU32(view: DataView, offset: number, value: number) {
  view.setUint32(offset, value >>> 0, true);
}

function createStoredZip(entries: Array<{ name: string; content: string }>): Blob {
  const encoder = new TextEncoder();
  const parts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  entries.forEach((entry) => {
    const nameBytes = encoder.encode(entry.name);
    const data = encoder.encode(entry.content);
    const crc = crc32(data);
    const local = new Uint8Array(30 + nameBytes.length);
    const localView = new DataView(local.buffer);
    writeU32(localView, 0, 0x04034b50);
    writeU16(localView, 4, 20);
    writeU16(localView, 6, 0x800);
    writeU16(localView, 8, 0);
    writeU16(localView, 10, 0);
    writeU16(localView, 12, 0);
    writeU32(localView, 14, crc);
    writeU32(localView, 18, data.length);
    writeU32(localView, 22, data.length);
    writeU16(localView, 26, nameBytes.length);
    writeU16(localView, 28, 0);
    local.set(nameBytes, 30);
    parts.push(local, data);

    const central = new Uint8Array(46 + nameBytes.length);
    const centralView = new DataView(central.buffer);
    writeU32(centralView, 0, 0x02014b50);
    writeU16(centralView, 4, 20);
    writeU16(centralView, 6, 20);
    writeU16(centralView, 8, 0x800);
    writeU16(centralView, 10, 0);
    writeU16(centralView, 12, 0);
    writeU16(centralView, 14, 0);
    writeU32(centralView, 16, crc);
    writeU32(centralView, 20, data.length);
    writeU32(centralView, 24, data.length);
    writeU16(centralView, 28, nameBytes.length);
    writeU16(centralView, 30, 0);
    writeU16(centralView, 32, 0);
    writeU16(centralView, 34, 0);
    writeU16(centralView, 36, 0);
    writeU32(centralView, 38, 0);
    writeU32(centralView, 42, offset);
    central.set(nameBytes, 46);
    centralParts.push(central);

    offset += local.length + data.length;
  });

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const eocd = new Uint8Array(22);
  const eocdView = new DataView(eocd.buffer);
  writeU32(eocdView, 0, 0x06054b50);
  writeU16(eocdView, 4, 0);
  writeU16(eocdView, 6, 0);
  writeU16(eocdView, 8, entries.length);
  writeU16(eocdView, 10, entries.length);
  writeU32(eocdView, 12, centralSize);
  writeU32(eocdView, 16, offset);
  writeU16(eocdView, 20, 0);

  return new Blob([...parts, ...centralParts, eocd], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
}

function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 0);
}

const PIE_COLORS = ['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#64748b'];

function makePieGradient(values: number[]): string {
  const total = values.reduce((a, b) => a + b, 0) || 1;
  let cursor = 0;
  const segments = values.map((value, index) => {
    const start = cursor;
    cursor += (value / total) * 100;
    return `${PIE_COLORS[index % PIE_COLORS.length]} ${start.toFixed(3)}% ${cursor.toFixed(3)}%`;
  });
  return `conic-gradient(${segments.join(', ')})`;
}

export const ReportsScreen: React.FC = () => {
  const {
    activeBusiness,
    activeSales,
    activeBusinessFinance,
    canAccessFinance,
    canViewSalesReport,
    currentSession,
  } = useTgp();

  const [dateFilter, setDateFilter] = useState<'TODAY' | 'WEEK' | 'MONTH'>('TODAY');

  const role = currentSession?.user.role as UserRole | undefined;
  const isCashier = role === UserRole.KASIR;
  const isServiceBusiness = activeBusiness?.templateType === BusinessTemplate.SERVICE;

  const visibleSales = useMemo(() => {
    return activeSales.filter((sale) => !isCashier || sale.cashierName === currentSession?.user.fullName);
  }, [activeSales, currentSession?.user.fullName, isCashier]);

  const filteredSales = useMemo(() => {
    const now = new Date();
    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);
    const weekStart = startOfWeek(now);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    return visibleSales.filter((sale) => {
      const time = new Date(sale.timestamp).getTime();
      if (dateFilter === 'TODAY') return time >= todayStart.getTime();
      if (dateFilter === 'WEEK') return time >= weekStart.getTime();
      return time >= monthStart.getTime();
    });
  }, [visibleSales, dateFilter]);

  const totalSalesRevenue = filteredSales.reduce((sum, sale) => sum + Number(sale.totalAmount || 0), 0);

  const bestSellers = useMemo(() => {
    const map = new Map<string, { name: string; quantity: number; revenue: number; type?: string }>();
    filteredSales.forEach((sale) => {
      (sale.items || []).forEach((item) => {
        const key = item.itemId || item.name;
        const row = map.get(key) || { name: item.name, quantity: 0, revenue: 0, type: undefined };
        row.quantity += Number(item.quantity || 0);
        row.revenue += Number(item.subtotal || (item.price * item.quantity) || 0);
        map.set(key, row);
      });
    });
    return Array.from(map.values()).sort((a, b) => b.quantity - a.quantity || b.revenue - a.revenue).slice(0, 5);
  }, [filteredSales]);

  const paymentMix = useMemo(() => {
    const map = new Map<string, number>();
    filteredSales.forEach((sale) => map.set(sale.paymentMethod, (map.get(sale.paymentMethod) || 0) + Number(sale.totalAmount || 0)));
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [filteredSales]);

  const servicePerformance = useMemo(() => {
    const map = new Map<string, { name: string; jobs: number; revenue: number; commission: number; ownerShare: number }>();
    filteredSales.forEach((sale) => {
      (sale.items || []).filter((item) => item.serviceStaffId || item.serviceStaffName).forEach((item) => {
        const key = item.serviceStaffId || item.serviceStaffName || 'unknown';
        const lineTotal = Number(item.subtotal || item.price * item.quantity || 0);
        const commission = Number(item.serviceCommissionAmount || 0);
        const row = map.get(key) || { name: item.serviceStaffName || 'Petugas', jobs: 0, revenue: 0, commission: 0, ownerShare: 0 };
        row.jobs += Number(item.quantity || 0);
        row.revenue += lineTotal;
        row.commission += commission;
        row.ownerShare += Number(item.serviceOwnerShareAmount ?? Math.max(0, lineTotal - commission));
        map.set(key, row);
      });
    });
    // Backward compatibility for historical SERVICE sales without item-level snapshots.
    filteredSales.forEach((sale) => {
      if ((sale.items || []).some((i) => i.serviceStaffId) || !sale.serviceStaffId || !sale.serviceStaffName) return;
      const key = sale.serviceStaffId;
      const row = map.get(key) || { name: sale.serviceStaffName, jobs: 0, revenue: 0, commission: 0, ownerShare: 0 };
      row.jobs += (sale.items || []).reduce((sum, item) => sum + Number(item.quantity || 0), 0) || 1;
      row.revenue += Number(sale.totalAmount || 0);
      row.commission += Number(sale.serviceCommissionAmount || 0);
      row.ownerShare += Number(sale.serviceOwnerShareAmount ?? Math.max(0, sale.totalAmount - Number(sale.serviceCommissionAmount || 0)));
      map.set(key, row);
    });
    return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue);
  }, [filteredSales]);

  const pieValues = bestSellers.map((row) => row.quantity);
  const bestSellerGradient = makePieGradient(pieValues.length ? pieValues : [1]);
  const paymentValues = paymentMix.map(([, value]) => value);
  const paymentGradient = makePieGradient(paymentValues.length ? paymentValues : [1]);

  const periodLabel = dateFilter === 'TODAY' ? 'Harian' : dateFilter === 'WEEK' ? 'Mingguan' : 'Bulanan';

  const handlePrint = () => window.print();

  const handleExportExcel = () => {
    const businessName = activeBusiness?.name || 'Bisnis';
    const createdAt = new Date();
    const salesRows: ExcelCell[][] = [
      ['Laporan Penjualan', periodLabel],
      ['Bisnis/Divisi', businessName],
      ['Dibuat', createdAt.toLocaleString('id-ID')],
      [],
      ['No', 'Tanggal', 'Waktu', 'Struk', 'Kasir', ...(isServiceBusiness ? ['Petugas Jasa'] : []), 'Rincian', 'Metode Pembayaran', 'Total'],
      ...filteredSales.map((sale, index) => {
        const stamp = new Date(sale.timestamp);
        return [
          index + 1,
          stamp.toLocaleDateString('id-ID'),
          stamp.toLocaleTimeString('id-ID'),
          sale.receiptNumber,
          sale.cashierName,
          ...(isServiceBusiness ? [sale.serviceStaffName || (sale.items || []).find((i) => i.serviceStaffName)?.serviceStaffName || '-'] : []),
          sale.itemsSummary,
          sale.paymentMethod,
          Number(sale.totalAmount || 0),
        ];
      }),
    ];

    const summaryRows: ExcelCell[][] = [
      ['Ringkasan', 'Nilai'],
      ['Periode', periodLabel],
      ['Total Penjualan', totalSalesRevenue],
      ['Jumlah Struk', filteredSales.length],
      [],
      ['Produk/Jasa Terlaris', 'Jumlah Terjual', 'Omzet'],
      ...bestSellers.map((row) => [row.name, row.quantity, row.revenue]),
    ];

    const paymentRows: ExcelCell[][] = [
      ['Metode Pembayaran', 'Total'],
      ...paymentMix.map(([name, value]) => [name, value]),
    ];

    const serviceRows: ExcelCell[][] = [
      ['Petugas', 'Jumlah Jasa', 'Omzet', 'Bagian Staff', 'Bagian Owner'],
      ...servicePerformance.map((row) => [row.name, row.jobs, row.revenue, row.commission, row.ownerShare]),
    ];

    const workbookXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Ringkasan" sheetId="1" r:id="rId1"/><sheet name="Penjualan" sheetId="2" r:id="rId2"/><sheet name="Produk Terlaris" sheetId="3" r:id="rId3"/><sheet name="Pembayaran" sheetId="4" r:id="rId4"/>${isServiceBusiness ? '<sheet name="Performa Jasa" sheetId="5" r:id="rId5"/>' : ''}</sheets></workbook>`;
    const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/>${isServiceBusiness ? '<Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet5.xml"/>' : ''}</Relationships>`;
    const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>`;
    const core = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>Laporan Penjualan ${xmlEscape(businessName)}</dc:title><dc:creator>TGP</dc:creator><dc:description>Laporan ${xmlEscape(periodLabel)}</dc:description></cp:coreProperties>`;
    const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>${isServiceBusiness ? '<Override PartName="/xl/worksheets/sheet5.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' : ''}</Types>`;

    const entries = [
      { name: '[Content_Types].xml', content: contentTypes },
      { name: '_rels/.rels', content: rootRels },
      { name: 'docProps/core.xml', content: core },
      { name: 'xl/workbook.xml', content: workbookXml },
      { name: 'xl/_rels/workbook.xml.rels', content: rels },
      { name: 'xl/worksheets/sheet1.xml', content: excelSheetXml(summaryRows) },
      { name: 'xl/worksheets/sheet2.xml', content: excelSheetXml(salesRows) },
      { name: 'xl/worksheets/sheet3.xml', content: excelSheetXml([['Produk/Jasa', 'Jumlah Terjual', 'Omzet'], ...bestSellers.map((row) => [row.name, row.quantity, row.revenue])]) },
      { name: 'xl/worksheets/sheet4.xml', content: excelSheetXml(paymentRows) },
    ];
    if (isServiceBusiness) entries.push({ name: 'xl/worksheets/sheet5.xml', content: excelSheetXml(serviceRows) });

    downloadBlob(createStoredZip(entries), `laporan-${toSafeFileName(businessName)}-${dateFilter.toLowerCase()}.xlsx`);
  };

  const handleExport = () => {
    const businessName = activeBusiness?.name || 'Bisnis';
    const bestRows = bestSellers.map((row, i) => `<tr><td>${i + 1}</td><td>${escapeHtml(row.name)}</td><td>${row.quantity}</td><td>${formatRupiah(row.revenue)}</td></tr>`).join('');
    const staffRows = servicePerformance.map((row) => `<tr><td>${escapeHtml(row.name)}</td><td>${row.jobs}</td><td>${formatRupiah(row.revenue)}</td><td>${formatRupiah(row.commission)}</td><td>${formatRupiah(row.ownerShare)}</td></tr>`).join('');
    const paymentLegend = paymentMix.map(([name, value], i) => `<div><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${PIE_COLORS[i % PIE_COLORS.length]}"></span> ${escapeHtml(name)} — ${formatRupiah(value)}</div>`).join('');
    const productLegend = bestSellers.map((row, i) => `<div><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${PIE_COLORS[i % PIE_COLORS.length]}"></span> ${escapeHtml(row.name)} — ${row.quantity} terjual</div>`).join('');
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>Laporan ${escapeHtml(businessName)}</title><style>body{font-family:Arial,sans-serif;color:#0f172a;padding:28px;max-width:1100px;margin:auto}h1{margin:0 0 5px}h2{margin-top:28px}p{color:#64748b}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #e2e8f0;text-align:left}th{background:#f8fafc}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.card{border:1px solid #e2e8f0;border-radius:16px;padding:18px}.pie{width:210px;height:210px;border-radius:50%;margin:auto 0 18px;background:${bestSellerGradient}}.pie2{width:210px;height:210px;border-radius:50%;margin:auto 0 18px;background:${paymentGradient}}.row{display:flex;gap:28px;align-items:flex-start}.legend{font-size:13px;line-height:1.8}@media print{body{padding:0}.no-print{display:none}}</style></head><body><h1>Laporan Penjualan ${escapeHtml(periodLabel)}</h1><p>${escapeHtml(businessName)} · dibuat ${new Date().toLocaleString('id-ID')}</p><div class="card"><strong>Total penjualan:</strong> ${formatRupiah(totalSalesRevenue)} &nbsp; <strong>Struk:</strong> ${filteredSales.length}</div><div class="grid"><div class="card"><h2>Diagram Roda Produk Terlaris</h2><div class="row"><div class="pie"></div><div class="legend">${productLegend || 'Belum ada data produk.'}</div></div></div><div class="card"><h2>Diagram Roda Metode Pembayaran</h2><div class="row"><div class="pie2"></div><div class="legend">${paymentLegend || 'Belum ada transaksi.'}</div></div></div></div><h2>Produk Terlaris</h2><table><thead><tr><th>No</th><th>Produk/Jasa</th><th>Jumlah</th><th>Omzet</th></tr></thead><tbody>${bestRows || '<tr><td colspan="4">Belum ada data</td></tr>'}</tbody></table>${isServiceBusiness ? `<h2>Performa Petugas Jasa</h2><table><thead><tr><th>Petugas</th><th>Jasa</th><th>Omzet</th><th>Bagian Staff</th><th>Bagian Owner</th></tr></thead><tbody>${staffRows || '<tr><td colspan="5">Belum ada data</td></tr>'}</tbody></table>` : ''}<p style="margin-top:30px;font-size:12px">Laporan ini hanya berisi data dari divisi/bisnis ${escapeHtml(businessName)} dan periode ${escapeHtml(periodLabel)}.</p></body></html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `laporan-${toSafeFileName(businessName)}-${dateFilter.toLowerCase()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!canViewSalesReport) {
    return <div className="p-12 text-center bg-white rounded-3xl border border-slate-200"><p className="text-sm text-rose-600 font-bold">Akses Terbatas: Laporan penjualan hanya dapat diakses oleh akun yang berwenang.</p></div>;
  }

  return (
    <div className="space-y-5 pb-20">
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white flex items-center justify-center shadow-md shadow-teal-600/20 shrink-0"><FileSpreadsheet className="w-6 h-6" /></div>
          <div>
            <span className="text-xs font-bold text-teal-600 uppercase tracking-wider">Laporan Penjualan</span>
            <h2 className="text-xl font-extrabold text-slate-900 leading-tight">{periodLabel} · {activeBusiness?.name}</h2>
            <p className="text-xs text-slate-500 font-medium">{isCashier ? 'Laporan khusus transaksi yang dilakukan Kasir ini.' : 'Laporan operasional bisnis/divisi aktif.'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExportExcel} className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"><FileSpreadsheet className="w-4 h-4" /> Excel</button>
          <button onClick={handleExport} className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-xl flex items-center gap-1.5"><Download className="w-4 h-4" /> HTML</button>
          <button onClick={handlePrint} className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl flex items-center gap-1.5"><Printer className="w-4 h-4" /> Cetak / PDF</button>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span className="font-bold text-slate-500 flex items-center gap-1"><Calendar className="w-4 h-4" /> Periode:</span>
        {(['TODAY', 'WEEK', 'MONTH'] as const).map((value) => <button key={value} onClick={() => setDateFilter(value)} className={`px-3 py-1.5 rounded-xl font-bold ${dateFilter === value ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>{value === 'TODAY' ? 'Harian' : value === 'WEEK' ? 'Mingguan' : 'Bulanan'}</button>)}
      </div>

      <div className={`grid grid-cols-1 ${canAccessFinance ? 'sm:grid-cols-3' : 'sm:grid-cols-2'} gap-3`}>
        <StatCard title="Total Penjualan" value={formatRupiah(totalSalesRevenue)} icon={<Receipt className="w-4 h-4" />} color="teal" subtitle={`${filteredSales.length} struk`} />
        <StatCard title="Rata-rata per Struk" value={formatRupiah(filteredSales.length ? totalSalesRevenue / filteredSales.length : 0)} icon={<TrendingUp className="w-4 h-4" />} color="blue" subtitle={periodLabel} />
        {canAccessFinance && <StatCard title="Saldo Bersih Unit" value={formatRupiah(activeBusinessFinance.netBalance)} icon={<DollarSign className="w-4 h-4" />} color={activeBusinessFinance.netBalance >= 0 ? 'blue' : 'rose'} subtitle="Khusus OWNER / ADMIN OWNER" />}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs"><div className="flex items-center gap-2 mb-4"><Trophy className="w-5 h-5 text-amber-500" /><h3 className="text-sm font-extrabold">Produk/Jasa Terlaris</h3></div>{bestSellers.length ? <div className="flex flex-col sm:flex-row gap-5 items-center"><div className="w-36 h-36 rounded-full border-8 border-white shadow-inner" style={{ background: bestSellerGradient }} /> <div className="flex-1 space-y-1.5 w-full">{bestSellers.map((row, i) => <div key={row.name} className="flex items-center justify-between text-xs"><span className="flex items-center gap-2 font-semibold truncate"><span className="w-2.5 h-2.5 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />{i + 1}. {row.name}</span><span className="font-black">{row.quantity}x</span></div>)}</div></div> : <p className="text-xs text-slate-400">Belum ada penjualan pada periode ini.</p>}</div>
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs"><div className="flex items-center gap-2 mb-4"><Receipt className="w-5 h-5 text-blue-500" /><h3 className="text-sm font-extrabold">Diagram Roda Pembayaran</h3></div>{paymentMix.length ? <div className="flex flex-col sm:flex-row gap-5 items-center"><div className="w-36 h-36 rounded-full border-8 border-white shadow-inner" style={{ background: paymentGradient }} /> <div className="flex-1 space-y-1.5 w-full">{paymentMix.map(([name, value], i) => <div key={name} className="flex items-center justify-between text-xs"><span className="flex items-center gap-2 font-semibold"><span className="w-2.5 h-2.5 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />{name}</span><span className="font-black">{formatRupiah(value)}</span></div>)}</div></div> : <p className="text-xs text-slate-400">Belum ada transaksi pada periode ini.</p>}</div>
      </div>

      {isServiceBusiness && <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3"><h3 className="text-sm font-extrabold">Performa Petugas Jasa</h3><div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-slate-100 text-slate-400 font-bold uppercase text-[10px]"><th className="py-2 px-3">Petugas</th><th className="py-2 px-3 text-right">Jasa</th><th className="py-2 px-3 text-right">Omzet</th><th className="py-2 px-3 text-right">Bagian Staff</th><th className="py-2 px-3 text-right">Bagian Owner</th></tr></thead><tbody className="divide-y divide-slate-100">{servicePerformance.length ? servicePerformance.map((row) => <tr key={row.name}><td className="py-3 px-3 font-extrabold">{row.name}</td><td className="py-3 px-3 text-right">{row.jobs}</td><td className="py-3 px-3 text-right font-bold">{formatRupiah(row.revenue)}</td><td className="py-3 px-3 text-right font-bold text-emerald-700">{formatRupiah(row.commission)}</td><td className="py-3 px-3 text-right font-bold text-blue-700">{formatRupiah(row.ownerShare)}</td></tr>) : <tr><td colSpan={5} className="py-8 text-center text-slate-400">Belum ada data jasa.</td></tr>}</tbody></table></div></div>}

      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs"><div className="flex items-center justify-between mb-3"><h3 className="text-sm font-extrabold">Rincian Penjualan</h3><span className="text-xs text-slate-400">{filteredSales.length} struk</span></div><div className="overflow-x-auto"><table className="w-full text-left text-xs"><thead><tr className="border-b border-slate-100 text-slate-400 font-bold uppercase text-[10px]"><th className="py-2.5 px-3">Struk / Waktu</th><th className="py-2.5 px-3">Kasir</th>{isServiceBusiness && <th className="py-2.5 px-3">Petugas Jasa</th>}<th className="py-2.5 px-3">Rincian</th><th className="py-2.5 px-3">Metode</th><th className="py-2.5 px-3 text-right">Total</th></tr></thead><tbody className="divide-y divide-slate-100">{filteredSales.length ? filteredSales.map((s) => <tr key={s.saleId}><td className="py-3 px-3"><div className="font-mono font-bold">{s.receiptNumber}</div><span className="text-[10px] text-slate-400">{new Date(s.timestamp).toLocaleString('id-ID')}</span></td><td className="py-3 px-3 font-semibold">{s.cashierName}</td>{isServiceBusiness && <td className="py-3 px-3">{s.serviceStaffName || (s.items || []).find((i) => i.serviceStaffName)?.serviceStaffName || '-'}</td>}<td className="py-3 px-3 max-w-xs truncate">{s.itemsSummary}</td><td className="py-3 px-3"><span className="px-2 py-0.5 rounded bg-blue-50 text-blue-700 font-bold text-[10px]">{s.paymentMethod}</span></td><td className="py-3 px-3 text-right font-black">{formatRupiah(s.totalAmount)}</td></tr>) : <tr><td colSpan={isServiceBusiness ? 6 : 5} className="py-8 text-center text-slate-400">Tidak ada penjualan pada periode ini.</td></tr>}</tbody></table></div></div>

      <div className="text-[10px] text-slate-400 flex items-center gap-1"><Package className="w-3.5 h-3.5" /> Laporan ini otomatis mengikuti bisnis/divisi aktif. Saat berpindah divisi, data dan diagram berubah sesuai divisi tersebut.</div>
    </div>
  );
};
