import React, { useState, useMemo } from 'react';
import {
  AlertCircle,
  ArrowRightLeft,
  BadgeCheck,
  Building2,
  Check,
  CheckCircle2,
  Clock,
  DollarSign,
  Package,
  Plus,
  Send,
  Store,
  TrendingDown,
  TrendingUp,
  Warehouse,
  X,
  XCircle,
} from 'lucide-react';
import { StatCard } from '../components/StatCard';
import { useTgp } from '../context/TgpContext';
import { TransferEntity, UserRole } from '../types';

export const TransferScreen: React.FC = () => {
  const {
    activeBusiness,
    activeItems,
    activeTransfers,
    businesses,
    items,
    outlets,
    requestStockTransfer,
    approveStockTransfer,
    rejectStockTransfer,
    isOwnerOrAdmin,
    currentSession,
  } = useTgp();

  const otherBusinesses = useMemo(
    () => businesses.filter((b) => b.businessId !== activeBusiness?.businessId),
    [businesses, activeBusiness]
  );

  const [toBizId, setToBizId] = useState<string>(
    otherBusinesses[0]?.businessId || ''
  );
  const [targetWarehouse, setTargetWarehouse] = useState<string>('Gudang Stok / Bahan Jadi');
  const [customWarehouse, setCustomWarehouse] = useState<string>('');
  const [itemId, setItemId] = useState<string>(activeItems[0]?.itemId || '');
  const [quantity, setQuantity] = useState<string>('10');
  const [notes, setNotes] = useState<string>('');
  const [customPrice, setCustomPrice] = useState<string>('');
  const [directApprove, setDirectApprove] = useState<boolean>(isOwnerOrAdmin);
  const [isRequestModalOpen, setIsRequestModalOpen] = useState<boolean>(false);

  const transferrableItems = activeItems.filter((i) => i.type !== 'SERVICE');
  const selectedItem = transferrableItems.find((i) => i.itemId === itemId);
  const selectedToBiz = businesses.find((b) => b.businessId === toBizId);

  // Available warehouse / destination locations for target business
  const destWarehouseOptions = useMemo(() => {
    const list: { label: string; value: string; isOutlet?: boolean }[] = [
      { label: 'Gudang Stok / Bahan Jadi (Gudang Utama)', value: 'Gudang Stok / Bahan Jadi' },
      { label: 'Gudang Bahan Baku', value: 'Gudang Bahan Baku' },
      { label: 'Gudang Pusat / Logistik', value: 'Gudang Pusat' },
    ];

    if (toBizId) {
      // Outlets belonging to target business
      const targetOutlets = outlets.filter((o) => o.businessId === toBizId);
      targetOutlets.forEach((o) => {
        list.push({
          label: `Stand / Outlet: ${o.name} (${o.location})`,
          value: `Outlet: ${o.name} - ${o.location}`,
          isOutlet: true,
        });
      });

      // Existing item locations in target business
      const existingItemLocs = Array.from(
        new Set(
          items
            .filter((i) => i.businessId === toBizId && i.location)
            .map((i) => i.location)
        )
      );
      existingItemLocs.forEach((loc) => {
        if (!list.some((existing) => existing.value.toLowerCase() === loc.toLowerCase())) {
          list.push({ label: `Lokasi Eksisting: ${loc}`, value: loc });
        }
      });
    }

    list.push({ label: '➕ Ketik Gudang / Lokasi Baru (Manual)...', value: 'CUSTOM' });
    return list;
  }, [toBizId, outlets, items]);

  // Unit price and total financial calculation
  const defaultUnitPrice = selectedItem
    ? selectedItem.costPrice > 0
      ? selectedItem.costPrice
      : selectedItem.sellingPrice
    : 0;

  const effectiveUnitPrice =
    customPrice !== '' && !isNaN(parseFloat(customPrice)) && parseFloat(customPrice) >= 0
      ? parseFloat(customPrice)
      : defaultUnitPrice;

  const numQty = parseFloat(quantity) || 0;
  const calculatedTotalValue = effectiveUnitPrice * numQty;

  const handleTransferSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!toBizId || !itemId) return;
    if (isNaN(numQty) || numQty <= 0) return;

    const finalDestLocation =
      targetWarehouse === 'CUSTOM'
        ? customWarehouse.trim() || 'Gudang Stok'
        : targetWarehouse;

    const ok = requestStockTransfer(
      toBizId,
      itemId,
      numQty,
      notes,
      finalDestLocation,
      effectiveUnitPrice,
      directApprove && isOwnerOrAdmin
    );

    if (ok) {
      setNotes('');
      setCustomWarehouse('');
      setCustomPrice('');
      setIsRequestModalOpen(false);
    }
  };

  const pendingCount = activeTransfers.filter((t) => t.status === 'PENDING').length;
  const approvedCount = activeTransfers.filter((t) => t.status === 'APPROVED').length;

  return (
    <div className="space-y-5 pb-20">
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-purple-600 text-white flex items-center justify-center shadow-md shadow-purple-600/20 shrink-0">
            <ArrowRightLeft className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-purple-600 uppercase tracking-wider">
                Mutasi Stok & Finansial Antar Unit Usaha
              </span>
            </div>
            <h2 className="text-xl font-extrabold text-slate-900 leading-tight">
              Transfer Stok Barang ({activeBusiness?.name})
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Pengirim dicatat sebagai <strong>PEMASUKAN</strong> &bull; Penerima dicatat sebagai <strong>PENGELUARAN</strong>
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            if (!toBizId && otherBusinesses.length > 0) {
              setToBizId(otherBusinesses[0].businessId);
            }
            if (!itemId && transferrableItems.length > 0) {
              setItemId(transferrableItems[0].itemId);
            }
            setDirectApprove(isOwnerOrAdmin);
            setIsRequestModalOpen(true);
          }}
          disabled={otherBusinesses.length === 0 || transferrableItems.length === 0}
          data-testid="btn_open_request_transfer"
          className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-xs flex items-center gap-1.5 transition"
        >
          <Plus className="w-4 h-4" />
          <span>+ Ajukan Transfer Stok</span>
        </button>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <StatCard
          title="Menunggu Persetujuan"
          value={`${pendingCount} Transaksi`}
          icon={<Clock className="w-4 h-4" />}
          color="amber"
          subtitle="Proses audit approval"
        />
        <StatCard
          title="Transfer Disetujui"
          value={`${approvedCount} Transaksi`}
          icon={<CheckCircle2 className="w-4 h-4" />}
          color="emerald"
          subtitle="Tercatat di laporan keuangan"
        />
        <StatCard
          title="Total Riwayat Transfer"
          value={`${activeTransfers.length} Rekod`}
          icon={<ArrowRightLeft className="w-4 h-4" />}
          color="purple"
          subtitle="Log mutasi stok & arus kas"
        />
      </div>

      {/* Transfer History Table */}
      <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-extrabold text-slate-900">Riwayat Mutasi Transfer Stok</h3>
            <p className="text-[11px] text-slate-500">
              Setiap transfer masuk ke laporan keuangan secara otomatis saat disetujui.
            </p>
          </div>
          <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full self-start sm:self-auto">
            {activeTransfers.length} Transaksi
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-2.5 px-3">Waktu & Ref</th>
                <th className="py-2.5 px-3">Rute & Gudang Tujuan</th>
                <th className="py-2.5 px-3">Barang & Qty</th>
                <th className="py-2.5 px-3">Nilai & Dampak Finansial</th>
                <th className="py-2.5 px-3 text-center">Status</th>
                {isOwnerOrAdmin && <th className="py-2.5 px-3 text-right">Aksi</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {activeTransfers.length === 0 ? (
                <tr>
                  <td colSpan={isOwnerOrAdmin ? 6 : 5} className="py-8 text-center text-slate-400 italic">
                    Belum ada riwayat transfer stok untuk unit bisnis ini.
                  </td>
                </tr>
              ) : (
                activeTransfers.map((tx) => {
                  const isPending = tx.status === 'PENDING';
                  const isApproved = tx.status === 'APPROVED';
                  const isRejected = tx.status === 'REJECTED';
                  const isSender = tx.sourceBusinessId === activeBusiness?.businessId;

                  return (
                    <tr key={tx.transferId} className="hover:bg-slate-50/80 transition">
                      {/* Waktu & Ref */}
                      <td className="py-3 px-3">
                        <div className="font-mono font-bold text-slate-900 text-xs">
                          {tx.transferReference || tx.transferId.slice(0, 8)}
                        </div>
                        <span className="text-[10px] text-slate-400">
                          {new Date(tx.createdAt).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                          })}
                        </span>
                        <div className="text-[10px] text-slate-500">
                          Oleh: {tx.requestedBy}
                        </div>
                      </td>

                      {/* Rute & Gudang Tujuan */}
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1 font-bold text-slate-800 text-xs">
                          <span className={isSender ? 'text-purple-700 font-extrabold' : 'text-slate-700'}>
                            {tx.sourceBusinessName}
                          </span>
                          <span className="text-slate-400">&rarr;</span>
                          <span className={!isSender ? 'text-purple-700 font-extrabold' : 'text-slate-700'}>
                            {tx.destBusinessName}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-indigo-700 font-semibold">
                          <Warehouse className="w-3 h-3 text-indigo-500 shrink-0" />
                          <span>Gudang Tujuan: {tx.destLocation || 'Gudang Stok'}</span>
                        </div>
                        {tx.notes && (
                          <span className="text-[10px] text-slate-400 italic block truncate max-w-xs mt-0.5">
                            "{tx.notes}"
                          </span>
                        )}
                      </td>

                      {/* Barang & Qty */}
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 text-xs">{tx.itemName}</div>
                        <span className="text-[11px] text-purple-700 font-extrabold">
                          {tx.quantity} pcs
                        </span>
                      </td>

                      {/* Nilai & Dampak Finansial */}
                      <td className="py-3 px-3">
                        <div className="font-extrabold text-slate-900 text-xs">
                          Rp {tx.totalValue.toLocaleString('id-ID')}
                        </div>
                        {isSender ? (
                          <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                            <TrendingUp className="w-2.5 h-2.5" />
                            Laporan Pemasukan
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-rose-700 bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">
                            <TrendingDown className="w-2.5 h-2.5" />
                            Laporan Pengeluaran
                          </span>
                        )}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-extrabold ${
                            isApproved
                              ? 'bg-emerald-100 text-emerald-800'
                              : isPending
                              ? 'bg-amber-100 text-amber-800 animate-pulse'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {isApproved ? 'DISETUJUI' : isPending ? 'MENUNGGU' : 'DITOLAK'}
                        </span>
                      </td>

                      {/* Aksi Cepat Owner */}
                      {isOwnerOrAdmin && (
                        <td className="py-3 px-3 text-right">
                          {isPending ? (
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => rejectStockTransfer(tx.transferId, 'Ditolak')}
                                title="Tolak Transfer"
                                className="px-2 py-1 bg-white border border-rose-200 hover:bg-rose-50 text-rose-600 rounded-lg text-[10px] font-bold transition flex items-center gap-0.5 shadow-2xs"
                              >
                                <X className="w-3 h-3" />
                                <span>Tolak</span>
                              </button>
                              <button
                                onClick={() => approveStockTransfer(tx.transferId)}
                                title="Setujui Transfer"
                                className="px-2.5 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-[10px] font-bold transition flex items-center gap-0.5 shadow-2xs"
                              >
                                <Check className="w-3 h-3" />
                                <span>Setujui</span>
                              </button>
                            </div>
                          ) : (
                            <span className="text-[10px] text-slate-400 font-medium">
                              {isApproved ? 'Selesai' : 'Ditolak'}
                            </span>
                          )}
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Request Modal */}
      {isRequestModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Ajukan Transfer Stok Barang</h3>
                <p className="text-xs text-slate-500">
                  Dari unit: <strong>{activeBusiness?.name}</strong>
                </p>
              </div>
              <button
                onClick={() => setIsRequestModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg text-lg font-bold"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleTransferSubmit} className="mt-4 space-y-3.5 text-xs">
              {/* Unit Bisnis Tujuan */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  1. Unit Bisnis Tujuan
                </label>
                <select
                  value={toBizId}
                  onChange={(e) => {
                    setToBizId(e.target.value);
                    setTargetWarehouse('Gudang Stok / Bahan Jadi');
                  }}
                  required
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-sm font-semibold"
                >
                  {otherBusinesses.map((b) => (
                    <option key={b.businessId} value={b.businessId}>
                      {b.name} ({b.templateType})
                    </option>
                  ))}
                </select>
              </div>

              {/* Pilihan Gudang Tujuan */}
              <div className="p-3 bg-purple-50/50 rounded-2xl border border-purple-100 space-y-2">
                <label className="block font-bold text-slate-800 flex items-center gap-1.5">
                  <Warehouse className="w-4 h-4 text-purple-600" />
                  <span>2. Pilihan Gudang / Lokasi Tujuan ({selectedToBiz?.name || 'Tujuan'})</span>
                </label>
                <select
                  value={targetWarehouse}
                  onChange={(e) => setTargetWarehouse(e.target.value)}
                  required
                  className="w-full px-3.5 py-2.5 border border-purple-200 bg-white rounded-xl focus:ring-2 focus:ring-purple-500 text-sm font-semibold text-slate-800"
                >
                  {destWarehouseOptions.map((opt, idx) => (
                    <option key={idx} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>

                {targetWarehouse === 'CUSTOM' && (
                  <div className="pt-1">
                    <label className="block font-bold text-purple-900 mb-1 text-[11px]">
                      Ketik Nama Gudang / Lokasi Baru:
                    </label>
                    <input
                      type="text"
                      value={customWarehouse}
                      onChange={(e) => setCustomWarehouse(e.target.value)}
                      placeholder="Contoh: Gudang Etalase / Stand B-03 / Rak Penyimpanan"
                      required
                      className="w-full px-3 py-2 border border-purple-300 bg-white rounded-xl focus:ring-2 focus:ring-purple-500 text-xs font-semibold"
                    />
                  </div>
                )}
                <p className="text-[11px] text-slate-500">
                  Barang yang ditransfer akan disimpan pada lokasi gudang ini di unit bisnis tujuan.
                </p>
              </div>

              {/* Pilih Barang */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  3. Pilih Barang yang Ditransfer
                </label>
                <select
                  value={itemId}
                  onChange={(e) => {
                    setItemId(e.target.value);
                    setCustomPrice('');
                  }}
                  required
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-sm font-semibold"
                >
                  {transferrableItems.map((item) => (
                    <option key={item.itemId} value={item.itemId}>
                      {item.name} &bull; Stok: {item.stockQuantity} {item.unit} (Lokasi Asal: {item.location || 'Gudang Stok'})
                    </option>
                  ))}
                </select>
              </div>

              {/* Jumlah & Nilai Transfer */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    4. Jumlah Transfer ({selectedItem?.unit || 'pcs'})
                  </label>
                  <input
                    type="number"
                    min="1"
                    max={selectedItem ? selectedItem.stockQuantity : undefined}
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                    required
                    className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-sm font-bold text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Tersedia: {selectedItem?.stockQuantity || 0} {selectedItem?.unit || 'pcs'}
                  </span>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Nilai Satuan (Rp)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={customPrice !== '' ? customPrice : defaultUnitPrice}
                    onChange={(e) => setCustomPrice(e.target.value)}
                    placeholder="Harga satuan"
                    className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-sm font-bold text-slate-900"
                  />
                  <span className="text-[10px] text-slate-400 mt-0.5 block">
                    Standar: Rp {defaultUnitPrice.toLocaleString('id-ID')} / {selectedItem?.unit || 'pcs'}
                  </span>
                </div>
              </div>

              {/* Dynamic Financial Impact Box */}
              <div className="p-3.5 bg-gradient-to-br from-purple-50 via-indigo-50/40 to-purple-50 rounded-2xl border border-purple-200/90 text-xs space-y-2">
                <div className="flex items-center justify-between font-bold text-slate-900">
                  <span className="flex items-center gap-1.5 text-purple-900">
                    <DollarSign className="w-4 h-4 text-purple-600" />
                    Total Nilai Transfer:
                  </span>
                  <span className="text-purple-700 text-base font-extrabold">
                    Rp {calculatedTotalValue.toLocaleString('id-ID')}
                  </span>
                </div>

                <div className="pt-2 border-t border-purple-200/60 space-y-1 text-[11px] leading-relaxed">
                  <div className="flex items-start gap-1.5">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span className="text-slate-700">
                      <strong>{activeBusiness?.name}</strong> (Bisnis Asal): Dicatat ke laporan{' '}
                      <strong className="text-emerald-700 bg-emerald-100 px-1 py-0.5 rounded">
                        PEMASUKAN (+ Rp {calculatedTotalValue.toLocaleString('id-ID')})
                      </strong>
                    </span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <TrendingDown className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                    <span className="text-slate-700">
                      <strong>{selectedToBiz?.name || 'Bisnis Tujuan'}</strong>: Dicatat ke laporan{' '}
                      <strong className="text-rose-700 bg-rose-100 px-1 py-0.5 rounded">
                        PENGELUARAN (- Rp {calculatedTotalValue.toLocaleString('id-ID')})
                      </strong>
                    </span>
                  </div>
                </div>
              </div>

              {/* Catatan Transfer */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Catatan / Alasan Transfer
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Contoh: Pemenuhan stok mendesak untuk stand cabang"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-sm"
                />
              </div>

              {/* Direct Approve Checkbox for Owner */}
              {isOwnerOrAdmin && (
                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-start gap-2.5">
                  <input
                    type="checkbox"
                    id="chk_direct_approve"
                    checked={directApprove}
                    onChange={(e) => setDirectApprove(e.target.checked)}
                    className="mt-0.5 w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-emerald-300"
                  />
                  <label htmlFor="chk_direct_approve" className="text-xs text-slate-700 cursor-pointer">
                    <strong className="text-emerald-900 block font-bold">
                      Langsung Setujui & Mutasi Otomatis (Instan)
                    </strong>
                    <span className="text-[11px] text-slate-500">
                      Stok akan langsung berpindah ke gudang tujuan dan laporan pemasukan/pengeluaran kedua bisnis langsung terbit tanpa perlu persetujuan ulang.
                    </span>
                  </label>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsRequestModalOpen(false)}
                  className="px-4 py-2 font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={!selectedItem || selectedItem.stockQuantity <= 0 || numQty <= 0}
                  className="px-5 py-2.5 font-bold text-white bg-purple-600 hover:bg-purple-700 disabled:opacity-50 rounded-xl shadow-xs flex items-center gap-1.5 transition"
                >
                  {directApprove && isOwnerOrAdmin ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Transfer & Bukukan Sekarang</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Kirim Pengajuan</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
