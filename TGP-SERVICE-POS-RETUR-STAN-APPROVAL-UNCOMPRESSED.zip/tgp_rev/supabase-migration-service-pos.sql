-- TGP SERVICE POS additive migration
-- Jalankan di Supabase SQL Editor untuk database TGP yang sudah ada.
ALTER TABLE public.sales ADD COLUMN IF NOT EXISTS service_staff_id TEXT;
ALTER TABLE public.sales ADD COLUMN IF NOT EXISTS service_staff_name TEXT;
ALTER TABLE public.sales ADD COLUMN IF NOT EXISTS service_commission_percent NUMERIC;
ALTER TABLE public.sales ADD COLUMN IF NOT EXISTS service_commission_amount NUMERIC;
ALTER TABLE public.sales ADD COLUMN IF NOT EXISTS service_owner_share_amount NUMERIC;
CREATE INDEX IF NOT EXISTS idx_sales_service_staff_id ON public.sales(service_staff_id);

-- 2026-09-07: Retur STAN oleh Kasir wajib Draft/PENDING dan menunggu approval Owner/Admin Owner.
ALTER TABLE public.stan_transfers ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'APPROVED';
ALTER TABLE public.stan_transfers ADD COLUMN IF NOT EXISTS requested_by TEXT;
ALTER TABLE public.stan_transfers ADD COLUMN IF NOT EXISTS requested_by_id TEXT;
ALTER TABLE public.stan_transfers ADD COLUMN IF NOT EXISTS approved_by TEXT;
ALTER TABLE public.stan_transfers ADD COLUMN IF NOT EXISTS processed_at BIGINT;
CREATE INDEX IF NOT EXISTS idx_stan_transfers_status ON public.stan_transfers(status);
CREATE INDEX IF NOT EXISTS idx_stan_transfers_outlet_status ON public.stan_transfers(outlet_id, status);
